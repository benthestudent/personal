/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package soundboard;

import java.net.MalformedURLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Babyc
 */
public class Soundboard {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        SoundBoardUI mainUI = new SoundBoardUI();
        mainUI.main();

    }
    
}
